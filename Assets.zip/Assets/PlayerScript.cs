using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;




    public class PlayerScript : NetworkBehaviour
    {
        private float moveX = 0.0f;
        private float speed = 110.0f;

        void Update()
        {
            if (!isLocalPlayer) 
                { return; }

            moveX = Input.GetAxis("Horizontal") * Time.deltaTime * 110.0f;
            float moveZ = Input.GetAxis("Vertical") * Time.deltaTime * 4f;

            transform.Rotate(0, moveX, 0);
            transform.Translate(0, 0, moveZ);
        }

        public void left()
        {
            Debug.Log("M.A");
            //moveX = Input.GetAxis("Horizontal") * speed;
            transform.Translate(6, 0, 0);

            //transform.Rotate(0, moveX, 0);
          //  transform.Translate(0, 0, moveZ);
        }
     

        
    }
