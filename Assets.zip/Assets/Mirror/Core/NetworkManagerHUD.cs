using UnityEngine;

namespace Mirror
{
    /// <summary>Shows NetworkManager controls in a GUI at runtime.</summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("Network/Network Manager HUD")]
    [RequireComponent(typeof(NetworkManager))]
    [HelpURL("https://mirror-networking.gitbook.io/docs/components/network-manager-hud")]
    public class NetworkManagerHUD : MonoBehaviour
    {
        // Increase button font size
        public int buttonFontSize = 40;

        // Increase button size
        public int buttonWidth = 300;
        public int buttonHeight = 195; // Modified button height

        NetworkManager manager;

        public int offsetX = 0;
        public int offsetY = 0;

        // Increase label font size
        public int labelFontSize = 27;

        void Awake()
        {
            manager = GetComponent<NetworkManager>();
        }

        void OnGUI()
        {
            GUILayout.BeginArea(new Rect(10 + offsetX, 40 + offsetY, 250, 9999));
            if (!NetworkClient.isConnected && !NetworkServer.active)
            {
                StartButtons();
            }
            else
            {
                StatusLabels();
            }

            // client ready
            if (NetworkClient.isConnected && !NetworkClient.ready)
            {
                if (GUILayout.Button("Client Ready", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    NetworkClient.Ready();
                    if (NetworkClient.localPlayer == null)
                    {
                        NetworkClient.AddPlayer();
                    }
                }
            }

            StopButtons();

            GUILayout.EndArea();
        }

        void StartButtons()
        {
            if (!NetworkClient.active)
            {
                // Server + Client
                if (Application.platform != RuntimePlatform.WebGLPlayer)
                {
                    if (GUILayout.Button("Host (Server + Client)", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                    {
                        manager.StartHost();
                    }
                }

                // Client + IP
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Client", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StartClient();
                }
                // This updates networkAddress every frame from the TextField
                manager.networkAddress = GUILayout.TextField(manager.networkAddress);
                GUILayout.EndHorizontal();

                // Server Only
                if (Application.platform == RuntimePlatform.WebGLPlayer)
                {
                    // cant be a server in webgl build
                    GUILayout.Box("(  WebGL cannot be server  )");
                }
                else
                {
                    if (GUILayout.Button("Server Only", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                    {
                        manager.StartServer();
                    }
                }
            }
            else
            {
                // Connecting
                GUILayout.Label($"Connecting to {manager.networkAddress}..");
                if (GUILayout.Button("Cancel Connection Attempt", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StopClient();
                }
            }
        }

        void StatusLabels()
        {
            // host mode
            // display separately because this always confused people:
            //   Server: ...
            //   Client: ...
            if (NetworkServer.active && NetworkClient.active)
            {
                GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
                labelStyle.fontSize = labelFontSize;
                GUILayout.Label($"<b>Host</b>: running via {Transport.active}", labelStyle);
            }
            // server only
            else if (NetworkServer.active)
            {
                GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
                labelStyle.fontSize = labelFontSize;
                GUILayout.Label($"<b>Server</b>: running via {Transport.active}", labelStyle);
            }
            // client only
            else if (NetworkClient.isConnected)
            {
                GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
                labelStyle.fontSize = labelFontSize;
                GUILayout.Label($"<b>Client</b>: connected to {manager.networkAddress} via {Transport.active}", labelStyle);
            }
        }

        void StopButtons()
        {
            // stop host if host mode
            if (NetworkServer.active && NetworkClient.isConnected)
            {
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Stop Host", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StopHost();
                }
                if (GUILayout.Button("Stop Client", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StopClient();
                }
                GUILayout.EndHorizontal();
            }
            // stop client if client-only
            else if (NetworkClient.isConnected)
            {
                if (GUILayout.Button("Stop Client", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StopClient();
                }
            }
            // stop server if server-only
            else if (NetworkServer.active)
            {
                if (GUILayout.Button("Stop Server", GUILayout.Width(buttonWidth), GUILayout.Height(buttonHeight))) // Modified button size
                {
                    manager.StopServer();
                }
            }
        }
    }
}
