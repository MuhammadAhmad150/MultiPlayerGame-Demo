Tanks demo to showcase simple networked movement, RPCs and SyncVars.
Also showcases Child-NetworkBehaviour components, see NetworkTransform on 'Turret'.